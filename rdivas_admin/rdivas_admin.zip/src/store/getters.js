export default {
    host: (state) => state.host,
    logHost: (state) => state.logHost,
    header: (state) => state.header,
    token: (state) => state.token,
    auth: (state) => state.auth,
    authError: (state) => state.authError,
    authMessage: (state) => state.authMessage,
    products: (state) => state.products,
    sel: (state) => state.sel,
    filteredProducts: (state) => state.filteredProducts,
}