<template>
    <top-sec />
    <bottom-sec />
</template>

<script>
import TopSec from '@/components/home/TopSec.vue';
import BottomSec from '@/components/home/BottomSec.vue';
export default {
    components: { TopSec, BottomSec },

}
</script>

<style scoped>
</style>